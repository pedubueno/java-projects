package com.aci.LiteZapper;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.dom4j.io.DOMReader;
import org.dom4j.io.DOMWriter;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Utils
{
	Document processFile(Document cartXmlDoc, Node fileNode, String fileName)
	{
		String CustomerValue = null;
		String xPathCmnd = null;

		int fileZaps = 0;
		int cnt = 1;

		XPath xpath = XPathFactory.newInstance().newXPath();

		try
		{
			NodeList entryNode = fileNode.getChildNodes();

			for (int x = 0; x < entryNode.getLength(); x++)
			{
				Node subnode = entryNode.item(x);

				if (subnode.getNodeType() == 1)
				{
					Element eElement = (Element) subnode;

					System.out.println("\nEntry " + cnt + " mode: " + (eElement.getTagName().equals("CEntry") ? "change" : "add"));
					cnt++;
					xPathCmnd = eElement.getAttribute("XPath");
					System.out.println("    XPath          : " + xPathCmnd);
					CustomerValue = eElement.getAttribute("CustVal");
					System.out.println("    Customer value : " + CustomerValue);

					NodeList nodes = null;
					if (eElement.getNodeName().equals("AEntry"))
					{
						org.dom4j.io.DOMReader reader = new DOMReader();
						org.dom4j.Document dom4jCartXmlDoc = reader.read(cartXmlDoc);

						XPathUtils.addElementOrAttributeToParent(dom4jCartXmlDoc, xPathCmnd, CustomerValue);
						// overlaps the normal file
						cartXmlDoc = (Document) new DOMWriter().write(dom4jCartXmlDoc);
						LiteZapper.ttlZaps += 1;
						fileZaps++;
					}
					else
					{
						nodes = (NodeList) xpath.evaluate(xPathCmnd, cartXmlDoc, XPathConstants.NODESET);

						if (nodes.getLength() == 0)
						{
							System.out.println("    No node found for xPath command " + xPathCmnd);
							System.exit(5);

						}
						else if (nodes.getLength() > 1)
						{
							System.out.println(
									"    Too many nodes (" + nodes.getLength() + ") found for xPath command " + xPathCmnd);

							for (int i = 0; i < nodes.getLength(); i++)
							{
								System.out.println("The value of i is: " + nodes.item(i).getNodeName());
							}
							System.exit(5);
						}
						else
						{
							System.out.println(
									"\n    Setting Customer value for " + nodes.item(0).getNodeName() + " to " + CustomerValue);
							nodes.item(0).setTextContent(CustomerValue);
							LiteZapper.ttlZaps += 1;
							fileZaps++;
						}
					}
				}
			}
		}
		catch (Exception e1)
		{
			e1.printStackTrace();
			System.exit(5);
		}

		System.out.println("\n Number of ZAPs    = " + fileZaps);

		if (fileZaps > 0)
		{
			return cartXmlDoc;
		}

		return null;
	}

}
