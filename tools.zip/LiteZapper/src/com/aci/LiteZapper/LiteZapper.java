package com.aci.LiteZapper;

import java.io.File;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class LiteZapper
{
	static int numArgs = 4;

	static int argMode = 0;
	static int argControlFile = 0;
	static int argInXML = 2;
	static int argOutXML = 3;

	static String mode = null;
	static String modeDesc = null;

	static Document jarDoc;
	static Document xmlDoc;

	static Document controlDoc;
	public static int ttlZaps = 0;

	public static void main(String[] args)
	{
		String controlFile = "";

		NodeList jarList = null;
		NodeList xmlList = null;

		Utils utils = new Utils();

		if (args.length < 1)
		{
			controlFile = "ControlFile.xml"; // args[argControlFile];
			System.err.println("Control File not specified. Assuming default ControlFile.xml in the root folder.");
		}
		else
		{
			controlFile = args[0];
		}

		try
		{
			// create the working dirs (input and output)
			createDirs();

			File cntlXMLfile = new File(controlFile);
			DocumentBuilderFactory cntlFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder cntlBuilder = cntlFactory.newDocumentBuilder();
			controlDoc = cntlBuilder.parse(cntlXMLfile);
			controlDoc.getDocumentElement().normalize();

			jarList = controlDoc.getElementsByTagName("JarFile");

			if (jarList.getLength() == 0)
			{
				System.err.println(
						"*** NO XML FILES FOUND *** The Control File " + controlFile + " does not contain any JAR files");
				System.exit(30);
			}

			System.out.println("################################################################################");
			System.out.println("#                                LITE ZAPPER                                   #");
			System.out.println("################################################################################");

			System.out.println("\nNumber of MCAS Jar files to process  :  " + jarList.getLength());

			// iterates over the jar list to get all XML
			for (int temp = 0; temp < jarList.getLength(); temp++)
			{
				Node fileNode = jarList.item(temp);

				if (fileNode.getNodeType() == 1)
				{
					Element eElement = (Element) fileNode;
					String jarFileName = eElement.getAttribute("name");

					// check if the given jar exists into the root directory
					File jarFile = new File(jarFileName + ".jar");
					if (!jarFile.exists())
					{
						System.out.println(
								"*** NO JAR FILE  FOUND *** The JAR File " + jarFileName + " does not exists into the root folder. Please put all jars related on the ControlFile in the root directory");
						System.exit(30);
					}

					// create the output folder for the zapped jars
					File outputDirectory = new File("liteZapper//output//" + jarFileName);
					outputDirectory.mkdirs();

					// create the input folder to uncompress the original jar
					File pathToExtract = new File("liteZapper//input//" + jarFileName);
					pathToExtract.mkdirs();

					// unzip this jar under the input folder
					unzipJar(jarFileName, pathToExtract);

					System.out.println("\n********************************************************************************");
					System.out.println("Processing JAR : " + jarFileName);

					xmlList = eElement.getElementsByTagName("XMLfile");

					if (xmlList.getLength() == 0)
					{
						System.err.println(
								"*** NO XML FILES FOUND *** The JAR File " + jarFileName + " does not contain any XML files");
						System.exit(30);
					}

					// iterate over the xml list of that jar
					for (int i = 0; i < xmlList.getLength(); i++)
					{

						Node xmlNode = xmlList.item(i);

						if (xmlNode.getNodeType() == 1)
						{
							Element xElement = (Element) xmlNode;
							String xmlFileName = xElement.getAttribute("file");

							System.out.println(
									"\n********************************************************************************");
							System.out.println("Processing XML : " + xmlFileName);

							File xmlFile = new File(pathToExtract.getPath() + "//" + xmlFileName);
							if (!xmlFile.exists())
							{
								System.out.println(
										"*** NO XML FILE  FOUND *** The XML File " + xmlFileName + " does not exists in the folder " + pathToExtract.getPath());
								System.exit(30);
							}
							
							DocumentBuilderFactory xmlFactory = DocumentBuilderFactory.newInstance();
							DocumentBuilder xmlBuilder = xmlFactory.newDocumentBuilder();
							xmlDoc = xmlBuilder.parse(xmlFile);
							xmlDoc.getDocumentElement().normalize();

							xmlDoc = utils.processFile(xmlDoc, xmlNode, xmlFileName);

							if (xmlDoc == null)
							{
								System.out.println("\nFile " + jarFileName + " does NOT need updating in Jar");
							}
							else
							{
								File file = new File(outputDirectory.getPath() + "//" + xmlFileName);

								String absolutePath = file.getAbsolutePath();
								String filePath = absolutePath.substring(0, absolutePath.lastIndexOf(File.separator));

								File file2 = new File(filePath);
								if ((!file2.exists()) && (!file2.mkdir()))
								{
									System.out.println("Failed to create directory " + filePath);
									System.exit(60);
								}

								xmlDoc.getDocumentElement().normalize();
								TransformerFactory transformerFactory = TransformerFactory.newInstance();
								Transformer transformer = transformerFactory.newTransformer();
								DOMSource source = new DOMSource(xmlDoc);

								StreamResult result = new StreamResult(file);
								transformer.setOutputProperty("omit-xml-declaration", "yes");
								transformer.setOutputProperty("indent", "yes");
								transformer.transform(source, result);

								System.out.println("\n XML file processed successfully");
							}
						}
					}
					System.out.println("\n Total Number of ZAPs    = " + ttlZaps);	
					System.out.println("\n All jars and files processed. Creating zapped jar under folder " + outputDirectory.getPath() + "...");
					
					// at the end, create the zapped jar
					createUpdatedJar(jarFileName, outputDirectory.toPath());
					System.out.println("\n Zapped jar created succesfully.");
				}
				
			}
		}
		catch (Exception e1)
		{
			e1.printStackTrace();
			System.exit(70);
		}
	}

	private static void createUpdatedJar(String jarFile, Path pathToExtract)
	{

		Runtime rt;
		Process pr;
		try
		{
			// saves the currentDirectory
			Path currentDir = FileSystems.getDefault().getPath("").toAbsolutePath();

			// Files.walk(pathToExtract.toPath()).filter(Files::isRegularFile).forEach(System.out::println);
			List<Path> files = Files.walk(pathToExtract).filter(Files::isRegularFile).collect(Collectors.toList());
			List<String> filesUnderJar = new ArrayList<String>();

			for (Path path : files)
			{
				filesUnderJar.add(path.toString().substring(pathToExtract.toString().length() + 1));
			}

			// reference to original jar
			File origJar = new File(currentDir.toString() + "//" + jarFile + ".jar");

			// reference to new jar
			File updatedJar = new File(pathToExtract + "//" + jarFile + ".jar");

			// copy the original jar to output jar
			Files.copy(origJar.toPath(), updatedJar.toPath());

			rt = Runtime.getRuntime();

			for (String updatedFile : filesUnderJar)
			{
				pr = rt.exec("jar -uvf " + jarFile + ".jar " + updatedFile, null, pathToExtract.toFile());
				pr.waitFor();
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private static void unzipJar(String jarFile, File pathToExtract)
	{
		Runtime rt;
		Process pr;
		try
		{
			rt = Runtime.getRuntime();
			pr = rt.exec("jar xvf " + new File("").getAbsolutePath() + "\\"+ jarFile + ".jar", null, pathToExtract);
			pr.waitFor();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	private static void createDirs()
	{
		// first, delete current liteZapper folder
		deleteDirectory(new File("liteZapper"));
		new File("liteZapper//input").mkdirs();
		new File("liteZapper//output").mkdirs();

	}

	private static boolean deleteDirectory(File directoryToBeDeleted)
	{
		File[] allContents = directoryToBeDeleted.listFiles();
		if (allContents != null)
		{
			for (File file : allContents)
			{
				deleteDirectory(file);
			}
		}
		return directoryToBeDeleted.delete();
	}

}
