package br.com.aci.utils;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;

public class DummyServerThreadManager extends Thread
{

	private String listenerName;

	private int localPort;
	private DummyServer myManager;
	private ArrayList<DummyServerThreadWorker> threadServerList;
	private boolean shouldIStop;

	public DummyServerThreadManager(String proxyName, int localPort, DummyServer myManager)
	{

		this.shouldIStop = false;
		this.listenerName = proxyName;
		this.localPort = localPort;

		// used when this manager stops itself
		this.myManager = myManager;
		this.threadServerList = new ArrayList<DummyServerThreadWorker>();
	}

	public void run()
	{

		ServerSocket server = null;
		Socket s = null;
		try
		{
			// Print a start-up message
			System.out.println("Starting listener " + listenerName + " on port " + localPort);
			server = new ServerSocket(localPort);
			server.setSoTimeout(1);
			while (!shouldIStop)
			{
				try
				{
					s = server.accept();
					DummyServerThreadWorker t = new DummyServerThreadWorker(s, this);
					synchronized (threadServerList)
					{
						threadServerList.add(t);
					}
				}
				catch (SocketTimeoutException e)
				{

				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}
		catch (IllegalArgumentException e)
		{
			// System.err.println("Usage: java -jar ProxyServerTimer " +
			// "<remotehost> <remoteport> <localport>");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (server != null)
			{
				try
				{
					server.close();
					System.out.println("Stoping listener  " + listenerName + " on port " + localPort);
				}
				catch (IOException e)
				{
				}
			}

			// closes the child connections
			synchronized (threadServerList)
			{
				for (DummyServerThreadWorker proxyServerThreadWorker : threadServerList)
				{
					proxyServerThreadWorker.informStop(true);
				}
			}
		}

	}

	public String getListenerName()
	{
		return listenerName;
	}

	public void removeThreadFromList(DummyServerThreadWorker thread)
	{
		synchronized (threadServerList)
		{
			threadServerList.remove(thread);

		}
	}

	public void informStop(boolean b)
	{
		shouldIStop = b;
	}

}
