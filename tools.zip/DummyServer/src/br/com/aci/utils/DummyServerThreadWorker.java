package br.com.aci.utils;

import java.net.Socket;
import java.net.SocketException;
import java.util.Arrays;

/**
 * Handles a socket connection from the client and sends a default response
 *
 *
 */
public class DummyServerThreadWorker extends Thread
{

	private Socket sClient;

	private long sendTimestamp;
	private long receiveTimestamp;
	private DummyServerThreadManager myManager;


	DummyServerThreadWorker(Socket sClient,DummyServerThreadManager myManager)
	{

		this.sClient = sClient;
		this.myManager = myManager;
		this.start();
	}

	@Override
	public void run()
	{
		try
		{
			Util.logTimeStamp(getListenerName(), "CONNECTION-" + (String.format("%04d", this.getId())) + " STARTED.");
			byte[] request = new byte[4096];
			int bytesToRead;

			while ((bytesToRead = sClient.getInputStream().read(request)) != -1)
			{
				String isoReq = Util.bytesToHex(Arrays.copyOf(request, bytesToRead));
				Util.logTimeStamp(myManager.getListenerName(), "REQUEST RECV FROM CLIENT. TOTAL BYTES:  " + bytesToRead
						+ " | HEX: " + isoReq);

				isoReq = isoReq.replaceFirst("0800", "0810");

				// Sends the response
				sClient.getOutputStream().write(Util.hexToBytes(isoReq), 0, bytesToRead);
				sClient.getOutputStream().flush();

				sendTimestamp = System.currentTimeMillis();

				Util.logTimeStamp(myManager.getListenerName(), "RESPONSE SENT TO CLIENT. TOTAL BYTES:  " + bytesToRead
						+ " | HEX: " + isoReq);
				// Util.logTimeStamp(myManager.getProxyName(), "CONNECTION-" +
				// String.format("%04d", this.getId() + " MESSAGE SENT TO HOST
				// "));
				//clear the byte array
				request = new byte[4096];
			}
		}
		catch (SocketException e)
		{
			//socket exception, connection closed. So, don't do anything
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			shutdownRealClientConnection();
		}
		myManager.removeThreadFromList(this);
		Util.logTimeStamp(getListenerName(), "CONNECTION-" + (String.format("%04d", this.getId())) + " FINISHED.");
	}

	private void shutdownRealClientConnection()
	{
		try
		{
			if (sClient != null)
			{
				// closes the server
				sClient.shutdownOutput();
				sClient.shutdownInput();
				sClient.close();
				sClient = null;
			}
		}
		catch (Exception e)
		{
			//e.printStackTrace();
		}
		sClient = null;
	}

	protected void informSendOrReceive(long timestamp)
	{
		receiveTimestamp = timestamp;

		if (sendTimestamp > 0 && receiveTimestamp > 0)
		{
			long totalTime = sendTimestamp - receiveTimestamp;
			Util.logTimeStamp(getListenerName(), "TOTAL TIME - " + (totalTime < 0 ? -totalTime : totalTime) + "ms.");
			sendTimestamp = 0;
			receiveTimestamp = 0;
		}
	}

	public String getListenerName()
	{
		return myManager.getListenerName();
	}

	public void informStop(boolean shouldManagerStop)
	{
		//someone called us to close, close the connections
		shutdownRealClientConnection();
	}
}
